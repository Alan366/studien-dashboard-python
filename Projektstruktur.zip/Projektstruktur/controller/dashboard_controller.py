# controller/dashboard_controller.py
from decimal import Decimal
from typing import Optional

from domain.semester import Semester
from domain.modul import Modul
from domain.modulstatus import Modulstatus
from domain.pruefungsleistung import Pruefungsleistung
from domain.zeitinvestition import Zeitinvestition

import datetime


class DashboardController:
    """
    Verbindet GUI und Domäne.
    Keine GUI-Logik, keine Dateiformate – nur Fachlogik & Koordination.
    """

    def __init__(self, repo):
        self.repo = repo
        self.studiengang = self.repo.load()
        if self.studiengang.semester_liste:
            self.aktuelles_semester = self.studiengang.semester_liste[0].nummer
        else:
            self.aktuelles_semester = 1

    # ---------- Semester / Module Zugriff ----------

    def get_semester_by_number(self, nummer: int) -> Optional[Semester]:
        for s in self.studiengang.semester_liste:
            if s.nummer == nummer:
                return s
        return None

    def get_semester_nummern(self) -> list[int]:
        return [s.nummer for s in self.studiengang.semester_liste]

    def wechsel_semester(self, nummer: int) -> None:
        self.aktuelles_semester = nummer

    # ---------- Kennzahlen für GUI ----------

    def get_uebersicht(self) -> dict:
        """
        Liefert alle Daten, die die GUI für das ausgewählte Semester braucht:
        - Gesamtdurchschnitt
        - Ist-/Zielstunden Semester
        - Durchschnittsnote Semester
        - Fortschritt (bestandene Module)
        - Modulliste
        """
        sem = self.get_semester_by_number(self.aktuelles_semester)

        if sem is None:
            return {
                "semester": None,
                "modules": [],
                "gesamt_durchschnitt": None,
                "sem_durchschnitt": None,
                "ist_stunden": 0,
                "ziel_stunden": 0,
                "bestandene_module": 0,
                "modul_anzahl": 0,
                "ziel_durchschnitt": self.studiengang.ziel_durchschnitt,
            }

        return {
            "semester": sem,
            "modules": sem.module,
            "gesamt_durchschnitt": self.studiengang.gesamtdurchschnitt,
            "sem_durchschnitt": sem.berechne_durchschnittsnote,
            "ist_stunden": sem.berechne_ist_arbeitsaufwand,
            "ziel_stunden": sem.ziel_arbeitsaufwand_h,
            "bestandene_module": sem.zaehle_bestandene_module,
            "modul_anzahl": len(sem.module),
            "ziel_durchschnitt": self.studiengang.ziel_durchschnitt,
        }

    # ---------- Mutationen (falls du später Eingaben einbaust) ----------

    def hinzufuegen_pruefungsleistung(
        self,
        modul: Modul,
        art: str,
        note: str,
        versuch: int,
        status: Modulstatus,
    ) -> None:
        modul.pruefungsleistungen.append(
            Pruefungsleistung(
                art=art,
                note=Decimal(note),
                versuch=versuch,
                datum=datetime.date.today(),
                status=status,
            )
        )

    def erfasse_zeit(self, modul: Modul, stunden: int, beschreibung: str) -> None:
        modul.zeitinvestitionen.append(
            Zeitinvestition(
                datum=datetime.date.today(),
                stunden=stunden,
                beschreibung=beschreibung,
            )
        )

    def speichere(self) -> None:
        self.repo.save(self.studiengang)

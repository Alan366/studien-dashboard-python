# create_module_excel.py
import pandas as pd

def main():
    data = [
        # Semester 1
        (1, "Betriebssystem und Verteile"),
        (1, "Math Grundlage 1"),
        (1, "IT-Sicherheit"),
        (1, "Python"),
        (1, "OOP python"),
        (1, "Math Grundlage 2"),
        # Semester 2
        (2, "Einführung in die Netzwerkforensik"),
        (2, "Statistik - Wahrscheinlichkeit und deskriptive Statistik"),
        (2, "Requirements Engineering"),
        (2, "Projekt: Agiles Projektmanagement"),
        (2, "Grundzüge des System-Pentestings"),
        # Semester 3
        (3, "Social Engineering und Insider Threats"),
        (3, "Technische und betriebliche IT-Sicherheitskonzeptionen"),
        (3, "Projekt: Social Engineering"),
        (3, "Theoretische Informatik und Mathematische Logik"),
        (3, "DevSecOps und gängige Software-Schwachstellen"),
        (3, "Praktikum: Informatik"),
        # Semester 4
        (4, "Kryptografische Verfahren"),
        (4, "Host- und Softwareforensik"),
        (4, "Seminar: Aktuelle Themen in Computer Science"),
        (4, "Projekt: Einsatz und Konfiguration von SIEM-Systemen"),
        (4, "Praktikum: Informatik"),
        # Semester 5
        (5, "Threat Modeling"),
        (5, "Standards der Informationssicherheit"),
        (5, "Projekt: Threat Modeling"),
        (5, "Praktikum: Informatik"),
        # Semester 6
        (6, "Bachelorarbeit"),
        (6, "Projekt: Allgemeine Programmierung mit C/C++"),
        (6, "Praktikum: Informatik"),
    ]

    df = pd.DataFrame(data, columns=["Semester", "Modulname"])
    df.to_excel("module.xlsx", index=False, sheet_name="Module")
    print("module.xlsx erstellt.")

if __name__ == "__main__":
    main()

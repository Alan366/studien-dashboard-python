# ui/main_view.py
import tkinter as tk
from tkinter import ttk


class MainView(tk.Frame):
    """
    GUI:
    - oben: Studiengang + Gesamtdurchschnitt + Semester-Dropdown
    - Mitte: Tabelle
    - unten: 3 KPI-Karten (Zeit, Durchschnitt, Fortschritt)
    """

    def __init__(self, parent, controller):
        super().__init__(parent, bg="white")
        self.controller = controller

        # ---------- TOP ----------
        top = tk.Frame(self, bg="white")
        top.pack(fill="x", padx=20, pady=10)

        left = tk.Frame(top, bg="white")
        left.pack(side="left")

        self.label_stg = tk.Label(
            left,
            text=controller.studiengang.name,  # z.B. "Cyber Security Bachelor"
            font=("Arial", 16, "bold"),
            bg="white",
        )
        self.label_stg.pack(anchor="w")

        self.label_gesamt = tk.Label(
            left,
            text="Gesamtdurchschnittsnote: –",
            font=("Arial", 12, "bold"),
            bg="white",
        )
        self.label_gesamt.pack(anchor="w", pady=(5, 0))

        right = tk.Frame(top, bg="white")
        right.pack(side="right")

        tk.Label(right, text="Semester", bg="white").pack(side="left", padx=5)

        self.sem_var = tk.IntVar()
        sem_list = self.controller.get_semester_nummern()
        self.sem_var.set(sem_list[0])

        self.sem_combo = ttk.Combobox(
            right,
            values=sem_list,
            textvariable=self.sem_var,
            width=5,
            state="readonly",
        )
        self.sem_combo.pack(side="left")
        self.sem_combo.bind("<<ComboboxSelected>>", self._on_semester_change)

        # ---------- TABELLE ----------
        table_frame = tk.Frame(self, bg="white")
        table_frame.pack(fill="both", expand=True, padx=20)

        cols = ("modul", "note", "zeit", "status")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings", height=12)
        self.tree.heading("modul", text="Modulname")
        self.tree.heading("note", text="Note")
        self.tree.heading("zeit", text="Zeitinvestition")
        self.tree.heading("status", text="Status")

        self.tree.column("modul", anchor="w", width=260)
        self.tree.column("note", anchor="center", width=80)
        self.tree.column("zeit", anchor="center", width=120)
        self.tree.column("status", anchor="center", width=140)

        self.tree.pack(fill="both", expand=True)

        # ---------- KPI-BEREICH ----------
        kpi_frame = tk.Frame(self, bg="white")
        kpi_frame.pack(fill="x", padx=20, pady=15)

        self.card_zeit = self._build_card(kpi_frame, "Gesamtzeitaufwand pro Semester")
        self.card_zeit.pack(side="left", expand=True, fill="x", padx=5)

        self.card_note = self._build_card(kpi_frame, "Durchschnittsnote")
        self.card_note.pack(side="left", expand=True, fill="x", padx=5)

        self.card_fortschritt = self._build_card(kpi_frame, "Fortschrittsanzeige")
        self.card_fortschritt.pack(side="left", expand=True, fill="x", padx=5)

        # Widgets in den Karten
        self.lbl_zeit = tk.Label(self.card_zeit, text="", bg="white")
        self.lbl_zeit.pack(anchor="w")
        self.pb_zeit = ttk.Progressbar(self.card_zeit, mode="determinate")
        self.pb_zeit.pack(fill="x")

        self.lbl_note = tk.Label(
            self.card_note, text="–", font=("Arial", 18, "bold"), bg="white"
        )
        self.lbl_note.pack()
        self.lbl_note_ziel = tk.Label(self.card_note, text="", bg="white")
        self.lbl_note_ziel.pack()

        self.lbl_fortschritt = tk.Label(self.card_fortschritt, text="", bg="white")
        self.lbl_fortschritt.pack(anchor="w")
        self.pb_fortschritt = ttk.Progressbar(self.card_fortschritt, mode="determinate")
        self.pb_fortschritt.pack(fill="x")

        # Initiales Rendering
        self._refresh()

    # ---------- Helpers ----------

    def _build_card(self, parent, title):
        frame = tk.Frame(parent, bg="white", bd=1, relief="solid")
        tk.Label(frame, text=title, font=("Arial", 10, "bold"), bg="white").pack(
            anchor="w", padx=10, pady=5
        )
        inner = tk.Frame(frame, bg="white")
        inner.pack(fill="both", expand=True, padx=10, pady=10)
        return inner

    def _on_semester_change(self, _event=None):
        self.controller.wechsel_semester(self.sem_var.get())
        self._refresh()

    def _fmt(self, value):
        if value is None:
            return "–"
        return str(round(float(value), 2)).replace(".", ",")

    def _refresh(self):
        data = self.controller.get_uebersicht()

        self.label_gesamt.config(
            text=f"Gesamtdurchschnittsnote: {self._fmt(data['gesamt_durchschnitt'])}"
        )

        # Tabelle
        for r in self.tree.get_children():
            self.tree.delete(r)

        for m in data["modules"]:
            self.tree.insert(
                "",
                "end",
                values=(
                    m.titel,
                    self._fmt(m.aktuelle_note),
                    f"{m.gesamt_zeitinvest} Std",
                    m.aktueller_status.value,
                ),
            )

        # KPI 1: Zeit
        ist = data["ist_stunden"]
        ziel = data["ziel_stunden"]
        self.lbl_zeit.config(text=f"{ist} von {ziel} Stunden")
        self.pb_zeit.config(maximum=ziel, value=ist)

        # KPI 2: Note
        self.lbl_note.config(text=self._fmt(data["sem_durchschnitt"]))
        self.lbl_note_ziel.config(
            text=f"pro Semester Ziel: {str(data['ziel_durchschnitt']).replace('.', ',')}"
        )

        # KPI 3: Fortschritt
        best = data["bestandene_module"]
        total = data["modul_anzahl"]
        self.lbl_fortschritt.config(text=f"{best} von {total} Modulen bestanden")
        self.pb_fortschritt.config(maximum=total, value=best)

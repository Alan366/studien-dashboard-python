from enum import Enum

class Modulstatus(Enum):
    BESTANDEN = "BESTANDEN"
    NICHT_BESTANDEN = "NICHT_BESTANDEN"
